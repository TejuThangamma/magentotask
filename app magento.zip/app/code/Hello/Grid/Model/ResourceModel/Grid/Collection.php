<?php
namespace Hello\Grid\Model\ResourceModel\Grid;


use Hello\Grid\Model\Grid;
use Hello\Grid\Model\ResourceModel\Grid as GridResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
       
       $this->_init(Grid::class, GridResourceModel::class);
    }
}