<?php
namespace Hello\PluginWorld\Model;
class Product extends \Magento\Catalog\Model\Product
{
    
    public function getName()
    {
        $name = parent::getName();
        // if($price<50){
            $name="Thangamma ".$name;
            // $name.=" Teju";
        // }
        // else{
        //     $name.=" Thangamma";
        // }
        return $name;
    }
}

