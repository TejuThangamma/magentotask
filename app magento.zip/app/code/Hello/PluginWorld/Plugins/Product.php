<?php
namespace Hello\PluginWorld\Plugins;
class Product{
    public function afterGetName(\Magento\Catalog\Model\Product $product, $name)
    {
        $price = $product->getData('price');
        // if($price<50){
            $name="Teju ".$name;
            // $name.=" Teju";
        // }
        // else{
        //     $name.=" Thangamma";
        // }
        return $name;
    }
}

