<?php
 
namespace Hello\TaskWorld\Controller\Save;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Context;
use Hello\TaskWorld\Model\View;
use Magento\Framework\App\ResponseInterface;
// use Hello\TaskWorld\Api\EmployeeRepositoryInterface;

class Save extends \Magento\Framework\App\Action\Action 
{
    private $carresourcemodel;
    private $car;
 
    public function __construct(Context $context,
    View $car,
    \Hello\TaskWorld\Model\ResourceModel\View $carresourcemodel)
    {
        $this->car = $car;
        $this->carresourcemodel = $carresourcemodel;
        parent::__construct($context);

    }
 
    public function execute()
    {
        
            $data = $this->getRequest()->getParams();
            
          
            if ($data) {
                $carModel = $this->car;
               
                $carModel->setData($data);
               
                // $this->model->Save($carModel);
                $this->carresourcemodel->save($carModel);
                $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
            }
        
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('taskworld');
 
    }
    // public function save()
    // {

    // }
}