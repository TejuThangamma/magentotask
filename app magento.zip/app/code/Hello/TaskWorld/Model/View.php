<?php

namespace Hello\TaskWorld\Model;

use Magento\Framework\Model\AbstractModel;
use Hello\TaskWorld\Model\ResourceModel\View as ResourceModel;

class View extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}