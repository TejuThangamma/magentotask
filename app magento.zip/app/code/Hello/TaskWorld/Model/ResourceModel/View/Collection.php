<?php
namespace Hello\TaskWorld\Model\ResourceModel\View;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Hello\TaskWorld\Model\View as Model;
use Hello\TaskWorld\Model\ResourceModel\View as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}