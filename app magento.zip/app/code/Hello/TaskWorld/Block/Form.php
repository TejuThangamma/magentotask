<?php
namespace Hello\TaskWorld\Block;
 
use Magento\Framework\View\Element\Template;
use Magento\Backend\Block\Template\Context;
use Hello\TaskWorld\Model\ResourceModel\View\Collection;
class Form extends Template
{

    private $collection;
    public function __construct(Context $context,  Collection $collection, array $data = [])
    {
        parent::__construct($context, $data);
        $this->collection = $collection;
    }
 
     public function getalldata()
     {
        return $this->collection;
     }
    public function getFormAction()
    {
        return $this->getUrl('extension/index/submit', ['_secure' => true]);
    }
    public function getAddCarPostUrl() {

        return $this->getUrl('taskworld/save/save');
    }
}